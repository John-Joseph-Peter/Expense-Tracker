package com.internshala.myexpense.activity

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.internshala.myexpense.R
import java.util.*

class RegisterActivity : AppCompatActivity() {
    lateinit var txtdob:TextView
    lateinit var etname:EditText
    lateinit var etmail:EditText
    lateinit var checkBox: CheckBox
    lateinit var checkBox2: CheckBox
    lateinit var btncreateAcc:Button


    lateinit var sharedPreferences: SharedPreferences


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sharedPreferences =
            getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)
        setContentView(R.layout.activity_register)

        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false)
        if (isLoggedIn) {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
        txtdob = findViewById(R.id.txtdob)
        etname = findViewById(R.id.etname)
        etmail = findViewById(R.id.etmail)
        btncreateAcc = findViewById(R.id.btncreateAcc)
        checkBox = findViewById(R.id.checkBox)
        checkBox2 = findViewById(R.id.checkBox2)

        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)

        txtdob.setOnClickListener {
            val dpd = DatePickerDialog(
                this,
                DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
                    txtdob.setText("" + dayOfMonth + "/" + month + "/" + year)
                }, year, month, day
            )
            dpd.show()
        }

        btncreateAcc.setOnClickListener {
            sharedPreferences.edit().putString("user_name", etname.text.toString()).apply()
            sharedPreferences.edit().putString("user_mail", etmail.text.toString()).apply()
            sharedPreferences.edit().putString("user_dob", txtdob.text.toString()).apply()

            savePreference()

            if (checkBox.isChecked()) {
                sharedPreferences.edit().putString("user_gender", "male").apply()
            } else if (checkBox2.isChecked()) {
                sharedPreferences.edit().putString("user_gender", "female").apply()
            }
            val intent=Intent(this,MobileVerificationActivity::class.java)
            startActivity(intent)
            finish()
        }




        }

  public  fun savePreference(){
        sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()

    }
}
