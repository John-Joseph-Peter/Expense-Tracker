package com.internshala.myexpense.activity


import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.alimuzaffar.lib.pin.PinEntryEditText
import com.internshala.myexpense.R


class OtpActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_otp)

        val pinEntry = findViewById(R.id.txt_pin_entry) as PinEntryEditText
        pinEntry?.setOnPinEnteredListener { str ->
            if (str.toString() == "1234") {
                Toast.makeText(
                    this,
                    "SUCCESS",
                    Toast.LENGTH_SHORT
                ).show()
                val intent= Intent(this,
                    MainActivity::class.java)
                startActivity(intent)
                finish()

            } else {
                Toast.makeText(
                    this,
                    "FAIL",
                    Toast.LENGTH_SHORT
                ).show()
                pinEntry.setText(null)
            }
        }
    }
}
