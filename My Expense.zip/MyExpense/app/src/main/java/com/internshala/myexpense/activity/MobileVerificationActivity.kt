package com.internshala.myexpense.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import com.internshala.myexpense.R

class MobileVerificationActivity : AppCompatActivity() {
lateinit var etmob_num:EditText
    lateinit var imgnext_verify:ImageView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mobile_verification)
        etmob_num=findViewById(R.id.etmob_num)
        imgnext_verify=findViewById(R.id.imgnext_verify)

        imgnext_verify.setOnClickListener {
            val intent = Intent(this, OtpActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
